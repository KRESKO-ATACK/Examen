public class Clientes {
    private String nombre;
    private String nip;
    private Cajero cajero;
            
    public Clientes(){
        Cajero c = new Cajero(90100);
        cajero =c;
    }
    public Clientes(String nombre, String nip){
        this.nombre = nombre;
        this.nip = nip;
    }
    
    public String getnombre(){
        return nombre;
    }
    public void setnombre(String nombre){
        this.nombre = nombre;
    }
    public String getnip(){
        return nip;
    }
    public void setnip(String nip){
        this.nip = nip;
    }
    public Cajero getcajero(Cajero cajero){
        return cajero;
    }
    public void setCajero(Cajero cajero){
        this.cajero = cajero;
    }
    @Override
    public String toString(){
        return "Nombre:"+nombre+"\nNip:"+nip+"Cajero:"+cajero;
    }
}
