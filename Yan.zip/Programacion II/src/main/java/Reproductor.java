
public class Reproductor  {
    protected String Titulo;
    protected int duracion;
    
    public Reproductor(){
        
    }

    public Reproductor(String Titulo, int duracion) {
        this.Titulo = Titulo;
        this.duracion = duracion;
    }

    public String getTitulo() {
        return Titulo;
    }

    public int getDuracion() {
        return duracion;
    }
    
    @Override
    public String toString(){
        return "Reproductor\nTitulo: "+Titulo+ "\nDuracion: "+duracion;
    }
    
}
