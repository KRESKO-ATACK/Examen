
public class Video extends Reproductor {
    private String formatoDegrabacion;
    
    public Video(){
        
    }

    public Video(String formatoDegrabacion, String Titulo, int duracion) {
        super(Titulo, duracion);
        this.formatoDegrabacion = formatoDegrabacion;
    }

    public String getFormatoDegrabacion() {
        return formatoDegrabacion;
    }
   
    @Override
    public String toString(){
        return "Video: \n Titulo del video: "+Titulo+"\n Duracion del Video: "+duracion+"\n"
                + "Cual es su formato de grabacion"+formatoDegrabacion;
    }
    
}
