import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;
public class Zapateria {
    private String Trabajador;
    private String cliente;
    private double zapatos;
    private double descuento;
    private int CantidadDeZapatos;
    private String marcaZapatos;
    
    //Sobre carga de contructores
    public Zapateria(){
    Trabajador = "Sebastian Moreno";
    zapatos = 600;
    descuento = 0.05;
    descuento = 0.15;
    }

    public Zapateria(String cliente, double zapatos ) {
        this.cliente = cliente;
        this.zapatos = zapatos;
    }

    public Zapateria(double descuento, int CantidadDeZapatos) {
        this.descuento = descuento;
        this.CantidadDeZapatos = CantidadDeZapatos;
    }
    //Metodos set y get
    //SET

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setZapatos(double zapatos) {
        this.zapatos = zapatos;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public void setCantidadDeZapatos(int CantidadDeZapatos) {
        this.CantidadDeZapatos = CantidadDeZapatos;
    }
    
    //GET

    public String getCliente() {
        return cliente;
    }

    public double getZapatos() {
        return zapatos;
    }

    public double getDescuento() {
        return descuento;
    }

    public int getCantidadDeZapatos() {
        return CantidadDeZapatos;
    }
    //Sobre carga de Metodos
    
    public void Comprar(){
        zapatos=500;
        
        Scanner s = new Scanner (System.in);
        CantidadDeZapatos = s.nextInt();
        
        Scanner a = new Scanner (System.in);
        System.out.println("Ingrese la marca del zapato:----");
        marcaZapatos = a.nextLine();
        
        System.out.println("Ingrese su nombre:-----");
        Scanner c = new Scanner (System.in);
        cliente = c.nextLine();
        
    }
    public void Comprar(double zapatos,String cliente,int CantidadDeZapatos){
        this.zapatos = zapatos;
        this.cliente = cliente;
        this.CantidadDeZapatos = CantidadDeZapatos;
        System.out.println("El precio de los Zapatos es: "+zapatos);
        System.out.println("La persona que lo atendio fue: "+Trabajador);
        System.out.println("La cantidad de zapatos es: "+CantidadDeZapatos);
       
    }
    public void Pagar(){
        zapatos = zapatos*CantidadDeZapatos;
        System.out.println(zapatos);
    }
    public double CalculaDescuento(){
        double descuento;
        
        if(zapatos < 100){
            System.out.println("No aplica");
        }
        else if(zapatos >= 1000 && (zapatos<=1500)){
            System.out.println("La compra tiene un 5% de descuento en el producto");
            descuento = zapatos;
            descuento = descuento*(0.05);
            zapatos=zapatos-descuento;
            System.out.println("Su total a pagar con el descuento es: "+zapatos);      
        }else if(zapatos>1500){
            System.out.println("La compra tiene un 15% de descuento en el producto");
            descuento = zapatos;
            descuento = descuento*(0.15);
            zapatos=zapatos-descuento;
            System.out.println("Su total a pagar con el descuento es:"+zapatos);
        }
            return 0;  
    }
    public void CalcularDescuento(String cliente,double zapatos,int CantidadDeZapatos){
        this.zapatos = zapatos;
        this.cliente = cliente;
        this.CantidadDeZapatos = CantidadDeZapatos;
        System.out.println("El descuento de tus zapatos es de:"+zapatos);
        System.out.println("El nombre del cliente es:"+cliente);
        System.out.println("La cantidad de zapatos que llevaste fue de: "+CantidadDeZapatos);
    }
    public void ImprimirTicket(){
        LocalTime horaActual = LocalTime.now();
        System.out.println("Hora: "+ horaActual);
        LocalDate fechaActual = LocalDate.now();
        System.out.println("Fecha: " + fechaActual);
        System.out.println("Nombre del Trabajador que lo atendio:"+Trabajador);
        System.out.println("Nombre del cliente"+cliente);
        System.out.println("Total a pagar:"+zapatos);
        System.out.println("Tu cantidad de zapatos que llevas es:"+CantidadDeZapatos);
        System.out.println("La marca de zapatos que llevas es: "+marcaZapatos);
        System.out.println("--------------------------------------\nTrabajador:"+Trabajador+"\nCleinte:"+cliente+""
            + "\nTotal a pagar: "+zapatos+"\n--------------------------------------\n***GRACIAS POR SU VISITA*** ");
    }
}
