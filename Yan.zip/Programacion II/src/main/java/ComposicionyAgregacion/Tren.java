package ComposicionyAgregacion;

public class Tren {
    private String nombre;
    private Vagon vagon1,vagon2,vagon3;
   //Constructores
 
    public Tren(String nombre) {
        this.nombre = nombre;
        
    }

    Tren() {
        
    }

    @Override
    public String toString() {
        return "NOMBRE DEL TREN: "+nombre;
    }

    
}
