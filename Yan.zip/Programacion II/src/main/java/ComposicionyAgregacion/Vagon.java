package ComposicionyAgregacion;
public class Vagon {
    
    private int id;
    private int capacidad;

    public Vagon(int id, int capacidad) {
        this.id = id;
        this.capacidad = capacidad;
      
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
    public void Vagon(int id, int capacidad){
        System.out.println("***Vagon***");
        System.out.println("Id"+id);
        System.out.println("Capacidad"+capacidad);
        
    }
    
    @Override
    public String toString() {
        return "******Vagon****** \n id = " + id + ", capacidad = " + capacidad ;
    }

    
    
   
}
