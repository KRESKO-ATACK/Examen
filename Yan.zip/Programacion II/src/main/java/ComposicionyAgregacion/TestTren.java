
package ComposicionyAgregacion;

public class TestTren {
    public static void main(String[] args){
        Tren tren = new Tren("Bruce");
        Vagon vagon1 = new Vagon(202048506,20);
        Vagon vagon2 = new Vagon(202048506,10);
        Vagon vagon3 = new Vagon(202048506,25);
        
        System.out.println(tren.toString());
        System.out.println(vagon1.toString());
        System.out.println(vagon2.toString());
        System.out.println(vagon3.toString()); 
        
        
    }
}
