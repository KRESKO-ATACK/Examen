public class Perro extends Annimal {
    
    private String raza;

    public Perro(String raza,String nombre) {
        super(nombre);
        this.raza = raza;
    }

    public void ladrar(){
        System.out.println("Guau..gua..");
    }
    
}
