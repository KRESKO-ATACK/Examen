
package Animal;

public class TestHerencia {
    public static void main (String[] args){
        Animal a = new Animal("Cococdrilo");
        Perro p = new Perro("")
    }
}
