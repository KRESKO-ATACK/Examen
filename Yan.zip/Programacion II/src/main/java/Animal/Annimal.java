public class Annimal {
    private String nombre;

    public Annimal(String nombre) {
        this.nombre = nombre;
    }
    public void respirar(){
        System.out.println(nombre+"Esta vivo");
    }
    
}
