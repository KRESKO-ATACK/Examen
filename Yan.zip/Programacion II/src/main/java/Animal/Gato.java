public class Gato extends Annimal {
    private String color;

    public Gato(String color,String nombre) {
        super(nombre);
        this.color = color;
    }

    public void maullar(){
        System.out.println("miau");
    }
    
}
