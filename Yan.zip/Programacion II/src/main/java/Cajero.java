import java.time.LocalDate; //Para la fecha
import java.time.LocalTime; //Para la hora
import java.util.Scanner;

public class Cajero {
    private int nip;
    private String cliente;
    private double saldo;
    private double r;
    private double d;
    private double saldoT;
    
    
    
    
//Constructores - Sobrecarga de constructures

public Cajero(){
    cliente = "Yan Josue Tepancal Martinez";
    saldo= 10000;
}

    public Cajero(double r, double d, double saldoT) {
        this.r = r;
        this.d = d;
        this.saldoT= saldoT;
    }

    public Cajero(int nip, double saldo) {
        this.nip = nip;
        this.saldo = saldo;
    }


//Métodos SET - Establecer  - Métodos GET - Obtener   

    public void setNip(int nip) {
        this.nip = nip;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setR(double r) {
        this.r = r;
    }

    public void setD(double d) {
        this.d = d;
    }

    public void setSaldoT(double saldoT) {
        this.saldoT = saldoT;
    }
    
    

    public int getNip() {
        return nip;
    }

    public String getCliente() {
        return cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getR() {
        return r;
    }

    public double getD() {
        return d;
    }

    public double getSaldoT() {
        return saldoT;
    }
   
    
    
//Metodos
    
    
    public boolean retirar() {
    Scanner s = new Scanner(System.in);
    System.out.println("Ingrese el monto a retirar.");
    r = s.nextDouble();
    if(r>saldo)
        return false;
    else{
        saldoT=saldo-r;
        return true;
    }
  }

    public double depositar(double d, double saldo){
    Scanner s = new Scanner(System.in);
    System.out.println("Ingrese la cantidad a depositar.");
    this.d = d;
    this.saldo = saldo;
    saldoT = this.d+this.saldo;
    return saldoT;
    }
    
    public void ingresar(){
    Scanner s = new Scanner(System.in);
    System.out.println("\nDigite su nip para acceder:");
    nip=s.nextInt();
    }
    
    public void imprimirTicketd(){
    System.out.println("\n---------------LOBOBANK---------------");    
    LocalTime horaActual = LocalTime.now(); 
    System.out.println("Hora: "+ horaActual);
    LocalDate fechaActual = LocalDate.now();
    System.out.println("Fecha: " + fechaActual);
    System.out.println("--------------------------------------\nNombre:"+cliente+"\nImporte:"+d+""
            + "\nSaldo Total: "+saldoT+"\n--------------------------------------\n***GRACIAS POR SU VISITA*** ");
    }
    
    public void imprimirTicketr(){
    System.out.println("\n---------------LOBOBANK---------------"); 
    LocalTime horaActual = LocalTime.now();
    System.out.println("Hora: "+ horaActual);
    LocalDate fechaActual = LocalDate.now();
    System.out.println("Fecha: " + fechaActual);
    System.out.println("--------------------------------------\nNombre:"+cliente+"\nRetiro:"+r+""
            + "\nSaldo Total: "+saldoT+"\n--------------------------------------\n***GRACIAS POR SU VISITA*** ");
    }
    
    public void imprimirTicket(){
    System.out.println("\n---------------LOBOBANK---------------"); 
    LocalTime horaActual = LocalTime.now();
    System.out.println("Hora: "+ horaActual);
    LocalDate fechaActual = LocalDate.now();
    System.out.println("Fecha: " + fechaActual);
    System.out.println("--------------------------------------\nNombre:"+cliente+""
            + "\nSaldo Total: "+saldo+"\n--------------------------------------\n***GRACIAS POR SU VISITA*** ");
    
    }
}