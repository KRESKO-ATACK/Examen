public class Superheroe {
    private String poder;
    private String mundo;
    private char genero;
    private double nivelpoder;
    private String nombre;
    
    //Constructores - Todos
    public Superheroe (){
        poder = "Visionlazer";
    }
    
    public Superheroe(String nombre,String mundo){
        this.nombre = nombre;
        this.mundo = mundo;
    }
    public Superheroe(String nombre, String mundo,double nivelpoder){
        this.nombre = nombre;
        this.mundo = mundo;
        this.nivelpoder = nivelpoder;
    }   
    
    //Metoos SET y GET - Obtener
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public void setMundo (String mundo){
        this.mundo = mundo;
    }
    
    public void setNivelpoder (double nivelpoder){
        this.nivelpoder = nivelpoder;
    }
    
    public void setPoder (String poder){
        this.poder = poder;
    }
    //GET
    public String getNombre (){
        return nombre;
    }
    
    public String getMundo (){
        return mundo;
    }
   public double getnivelpoder (){
       return nivelpoder;
    }
   public String getPoder (){
       return poder;
    }
   
   //Metodos
   
   void revisarlaCiudad(){
       System.out.println(nombre+ "No hay preligro en la ciudad....");
   }
   
   void golpear (){
       System.out.println(nombre+ "Quemar y golpear a ladrones..");
   }
   
   void rayoslazer (){
       System.out.println(nombre+ "Hacer explotar automovil de villano");
   }
   
   void Volar (){
       System.out.println(nombre+ "Revisar el mundo de villanos");
   }
   
   void casa (){
       System.out.println(nombre+ "LLegar a comer pancito con leche");
   }
}