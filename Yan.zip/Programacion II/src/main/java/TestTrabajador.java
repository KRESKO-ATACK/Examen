
import java.util.Scanner;

public class TestTrabajador {

    
    public static void main(String[]args){
        Scanner s = new Scanner(System.in);
        Trabajador c = new Trabajador();
        int opcion;
        
        System.out.println("\n ------------BIENVENIDO-----------");
        do{
            System.out.println("------¿QUE MOVIMIENTOS QUIERE HACER?------");
            System.out.println("1.Sueldo \n2. Imprimir Recibo \n3 Salir");
            opcion = s.nextInt();
            switch(opcion){
                case 1->{
                    System.out.println("Ingresa tus horas:");
                     c.calcularSueldo();
                }
                case 2->{
                    System.out.println("Imprimir recibo");
                    c.imprimirRecibo();
                    
                }
                case 3->{
                    System.out.println("ADIOS VUELVA PRONTO");
                }
                default->
                    System.out.println("Opcion invalida");
            }
        }while(opcion!=3);
    }
}
