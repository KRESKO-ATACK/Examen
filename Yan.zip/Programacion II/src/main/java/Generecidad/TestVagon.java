
package Generecidad;

import java.util.Scanner;
public class TestVagon {
    public static void main (String[]args){
        Scanner s = new Scanner(System.in);
        int opcion;
        boolean apuntaViaMuerta=false;
        ViaMuerta <Vagon> via = new ViaMuerta<>(5);
 
        Vagon vagon1 = new Vagon("Pepe",55,7);
        Vagon vagon2 = new Vagon("Pedro",10,6);
        Vagon vagon3 = new Vagon("Poncho",20,5);
        Vagon vagon4 = new Vagon("Rocio",54,4);
        Vagon vagon5 = new Vagon("Tomas",86,3);

        do{
            System.out.println("------------FUNCIONAMIENTO DE TRENES-----------");
            System.out.println("""
                               Capacidad de la via muerta: 5
                               1. Aparcar vag\u00f3n
                               2. Sacar vag\u00f3n
                               3. Imprimir
                               4. Salir""");
            opcion = s.nextInt();
            switch(opcion){
                case 1 -> {
                    if(!apuntaViaMuerta){
                        System.out.println("---Datos del Vagon---");
                        apuntaViaMuerta=true;
                    }
                    if(via.esLlena()){
                        System.out.println("No hay espacio");
                    }else{
                        Vagon nuevoVagon = new Vagon();
                                
                        System.out.println("Nombre--");
                        nuevoVagon.setNombre(s.next());
                        
                        System.out.println("Capacidad--");
                        nuevoVagon.setCapacidad(s.nextInt());
                     
                        System.out.println("Numero del vagon--");
                        nuevoVagon.setNumeroVagon(s.nextInt());
                        
                        System.out.println("---Insertandolos en Via Muerta---");
                        via.apilar(nuevoVagon);
                    }
                }
                case 2 -> {
                    System.out.println("Cambiando el sentido de agujas..");
                    if(apuntaViaMuerta){
                    apuntaViaMuerta=false;
                    }
                    System.out.println("-----------------");
                    via.desapilar();
                }
                case 3 -> {
                    System.out.println("---Vagones estacionados---");
                    via.mostrar();
                    System.out.println("-----------------");
                }
                case 4 -> System.out.println("---Goosbay---");
                default -> System.out.println("---Opcion incorrecta---");
            }
        }while(opcion != 4);
    }
}
