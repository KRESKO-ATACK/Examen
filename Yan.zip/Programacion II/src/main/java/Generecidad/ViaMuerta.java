
package Generecidad;

public class ViaMuerta <T> {
    private final int capacidad;
    private int cima;
    private final Object vias[];
    
    public ViaMuerta(int capacidad){
        this.capacidad = capacidad;
        vias = new Object[capacidad];
        cima = -1;
    }
    
    public boolean esVacia(){
        return cima == -1;
    }
    
    public boolean esLlena(){
        return cima == capacidad-1;
    }
    
    public void apilar(T elemento){
        if(!esLlena()){   // if(esLlena()== false)
            cima = cima+1;
            vias[cima]= elemento;
        }
        else
            System.out.println("Via llena. ");
    }
    
    public void desapilar(){
        if(!esVacia())
            cima = cima-1;
        else
            System.out.println("Via vacia.");
    }
    
    public void obtenerCima(){
        if(!esVacia())
            System.out.println("Cima: "+vias[cima]);
        else
            System.out.println("vagon vacio.");
    }
    
    public void mostrar(){
        if(!esVacia()){
            System.out.println("------- Via Muerta --------");
            for(int i=cima; i>=0; i--)
                System.out.println(vias[i]);
        }
        else
           System.out.println("Via vacia.");        
    }

    
}
