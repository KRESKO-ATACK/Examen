package Generecidad;

public class Vagon {
    private String nombre;
    private int capacidad;
    private int NumeroVagon;   
    
    public Vagon (){
        nombre = "Pepe";
        capacidad = 55;
        NumeroVagon = 7;
    }

    public Vagon(String nombre, int capacidad, int NumeroVagon) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.NumeroVagon = NumeroVagon;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public void setNumeroVagon(int NumeroVagon) {
        this.NumeroVagon = NumeroVagon;
    }

    @Override
    public String toString(){
        return "\nNombre del vagon:"+nombre+"\ncapacidad"+capacidad+"\nNumero del Vagon:"+NumeroVagon;
}

}
