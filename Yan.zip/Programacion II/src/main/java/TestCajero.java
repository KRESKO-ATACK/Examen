import java.util.Scanner;

public class TestCajero {
   public static void main(String[] args){
   Scanner s = new Scanner(System.in);
   Cajero c = new Cajero();
   int opcion; 
   
   System.out.println("\n**********BIENVENIDO**********");
   c.ingresar();
   
   do{ 
       System.out.println("\nHola, ¿qué deseas hacer?\n");
       System.out.println("1. Retirar \n2. Depositar \n3. Imprimir Ticket \n4.Salir ");
       opcion = s.nextInt();
       switch(opcion){
           case 1 -> {        
               if(c.retirar() == false)
                   System.out.println("¡El retiro solicitado supera el saldo de su cuenta!");
               else
                   System.out.println("¡El retiro fue exitoso!");
               c.imprimirTicketr();
           }
           case 2 -> {
               System.out.println("Ingrese la cantidad a depositar.");
               c.setD(s.nextDouble());
               System.out.println("!Su deposito de: $"+c.depositar(c.getD(),c.getSaldo())+", fue exitoso! ");
               c.imprimirTicketd();
           }
           case 3 -> c.imprimirTicket();
           default -> System.out.println("Opcion invalida...");
                   
       }
   
   }while(opcion !=4);
   
   }  
}