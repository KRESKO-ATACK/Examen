import java.util.Scanner;

public class TestGato {
    public static void main(String[] args) {
        //Constructor
        //Nombre Clase nombreObjeto = new Constructor();
        //Gato miGato = new Gato(); //Constructor por default
        Scanner s = new Scanner(System.in);  // Instancia 
        String cad;
        
        Gato miGato2 = new Gato(); // Instanciar (Crear objeto) 
        
        System.out.println("Nombre: ");
        cad = s.next();       // Metodo
        miGato2.setNombre(cad);   // Metodo
        //miGato2.nombre = s.next();
        
        System.out.println("Raza: "); // M
        cad = s.next();    // M
        miGato2.setRaza(cad);  // M
        //miGato2.raza = s.next();
 
        System.out.println("Mi gato se llama: "+ miGato2.getNombre()); //M
        
        miGato2.arañar(); //M
           
    }    
}