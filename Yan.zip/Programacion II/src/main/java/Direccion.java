package Composicion;

public class Direccion {
    private String calle;
    private int numero;
    private String ciudad;
    private String pais;
    private int CodigoPostal;
    
    public Direccion(String calle, int numero, String ciudad, String ciudad,String pais, int CodigoPostal) {
        this.calle = calle; 
        this.numero = numero;
        this.ciudad = ciudad;
        this.pais = pais;
        this.CodigoPostal = CodigoPostal;    
    }
    
}