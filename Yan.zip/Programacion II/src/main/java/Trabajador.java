import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;
public class Trabajador {
    private double sueldo;      // EL SUELDO ES DE 1432.8
    private int horastrabajadas; //40 HORAS A LA SEMANA QUE SON 5 DIAS
    private double salario;   //SALARIO EN MEXICO ES DE 35.82 POR HORA
    private String nombre;
    private int id;
    
    
    //Constructores- Sobre carga de contructores
    public Trabajador(){
        nombre = "Sebastian Moreno Soto";
        id = 260901;
        salario = 35.82;
    }
    public Trabajador(String nombre, int id){
        this.nombre = nombre;
        this.id = id;
    }
    public Trabajador(double sueldo, double salario){
        this.sueldo = sueldo;
        this.salario = salario;
    }
    // Metodos SET y GET
    public void setsueldo(double sueldo){
        this.sueldo = sueldo;
    }
    public void sethorastrabajadas(int horastrabajadas){
        this.horastrabajadas = horastrabajadas;
    }
    public void setsalario(double salario){
        this.salario = salario;
    }
    public void setnombre(String nombre){
        this.nombre = nombre;
    }
    public void setid (int id){
        this.id = id;
    }
    //GET
    public double getsueldo(){
        return sueldo;
    }
    public int gethorastrabajadas(){
        return horastrabajadas;
    }
    public double getsalario(){
        return salario;
    }
    public String getnombre(){
        return nombre;
    }
    public int getid(){
        return id;
    }
    
    //Sobre carga de Metodos
    
    public void calcularSueldo(int horastrabajadas,double salario){
      salario=35.82;
        Scanner a = new Scanner(System.in);
        horastrabajadas = a.nextInt();
        if(horastrabajadas <= 40)
        {
            sueldo = horastrabajadas*35.82;
        }
        else if (horastrabajadas <=48)
        {
            sueldo = (40*35.82) + (horastrabajadas-40)*2*71.64;
            
        }
    }
    
    
    
    public double calcularSueldo(){
        salario=35.82;
        Scanner a = new Scanner(System.in);
        horastrabajadas = a.nextInt();
        if(horastrabajadas <= 40)
        {
            sueldo = horastrabajadas*35.82;
        }
       return sueldo;
    }
   
    public void horasextra(){
        salario=35.82;
        Scanner a = new Scanner(System.in);
        horastrabajadas = a.nextInt();
        if(horastrabajadas <= 40)
        {
            sueldo = horastrabajadas*35.82;
        }
        else if (horastrabajadas <=48)
        {
            sueldo = (40*35.82) + (horastrabajadas-40)*2*71.64;
            
        }
    
    }
    public void horasextra(int horasextra){
        this.horastrabajadas = horastrabajadas;
        System.out.println("Horas extras: "+horastrabajadas);
    }
    
    public void imprimirRecibo(double sueldo,int horastrabajadas){
       this.sueldo = sueldo;
       this.horastrabajadas=horastrabajadas;
       System.out.println("Sueldo: "+sueldo);
       System.out.println("Horas trabajadas: "+horastrabajadas);
    }
   
    public void imprimirRecibo(){
        LocalTime horaActual = LocalTime.now();
        System.out.println("Hora: "+ horaActual);
        LocalDate fechaActual = LocalDate.now();
        System.out.println("Fecha: " + fechaActual);
        System.out.println("Nombre de empleado: " + nombre);
        System.out.println("ID: " + id);
        System.out.println("Horas trabajadas: " + horastrabajadas);
        System.out.println("Tu sueldo es de " + sueldo + " pesos");
        System.out.println("--------------------------------------\nNombre:"+nombre+"\nSalario:"+salario+""
            + "\nSueldo total: "+sueldo+"\n--------------------------------------\n***GRACIAS POR SU VISITA*** ");
    }
    
}
