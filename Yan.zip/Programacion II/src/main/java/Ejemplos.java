
public class Ejemplos {
    private int n;

    public Ejemplos(int n) {
        this.n = n;
    }
    
    
    
    double f(double x , int n){
        if (n == 0)
            return 0;
        else
            return n + f(x, n-1);
    }
         
}
