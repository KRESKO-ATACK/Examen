public class Gato {
    //Atributos
    private String colorPelaje;
    private String raza;
    private double tamaño;
    private char genero;
    private String nombre;
    
    //Constructores - Sobrecarga de constructores
    public Gato(){
        colorPelaje = "negro";
    }
    
    public Gato(String nombre){
        this.nombre=nombre;
    }
    
    public Gato(String nombre, String raza){
        this.nombre=nombre;
        this.raza=raza;
    }
    
    public Gato(String nombre, String raza, double tamaño){
        this.nombre = nombre;
        this.raza = raza;
        this.tamaño = tamaño;
    }
    
    //Métodos SET - Establecer  - Métodos GET - Obtener
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public void setRaza(String raza){
        this.raza = raza;
    }
    
    public void setTamaño(double tamaño){
        this.tamaño = tamaño;
    }
    
    
    public String getNombre(){
        return nombre;
    }
    
    public String getRaza(){
        return raza;
    }
    
    public double getTamaño(){
        return tamaño;
    }
    
    //Metodos
    void maullarAzotea(){
        System.out.println(nombre+ " dice Miau... Miau...");
    }
    
    void arañar(){
        System.out.println(nombre+ " esta arañando el sillon... ");
    }
    
    void comer(){
        System.out.println(nombre+ " esta comiendo wiskas ... Ñam.. Ñam...");
    }
    
    void dormir(){
        System.out.println(nombre + " esta Zzzz...Zzzz...");
    }   
}