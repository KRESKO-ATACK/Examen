package Pila;
import java.util.Scanner;

public class TestPila {
     public static void main(String[] args) {
        int opcion=0,cap;
        Scanner s = new Scanner(System.in);
        System.out.println("Ingrese la capacidad de su pila: ");
        cap=s.nextInt();
        Pila p=new Pila(cap);
        do{
            System.out.println("---Menu---");
            System.out.println("\n1.Apilar");
            System.out.println("\n2.Desapilar");
            System.out.println("\n3.MostrarCima");
            System.out.println("\n4.Mostrar");
            System.out.println("\n5.Salir");
            opcion=s.nextInt();
            switch(opcion){
                case 1:System.out.println("Ingrese el elememto a apilar: ");
                        cap=s.nextInt();
                        p.Apilar(cap);
                break;
                case 2:p.desapilar();
                    System.out.println("Desapilado");
                break;
                case 3:p.ObtenerCima();
                break;
                case 4:p.mostrar();
                break;
                case 5:System.out.println("Finalizando..");
                break;
                default: System.out.println("Opcion Incorrecta-");
                break;
            }
        }while(opcion!=5);
    }
}
