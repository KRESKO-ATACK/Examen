package Pila;

public class Pila {
    int capacidad,cima;
    int vector[];
    public Pila(int capacidad) {
        this.capacidad=capacidad;
        vector=new int[capacidad];
        cima=-1;
    }
    public boolean esVacia(){
        if(cima==-1){
            return true;
        }else{
            return false;
        }
    }
    public boolean esLlena(){
        if(cima==capacidad-1){
            return true;
        }else{
            return false;
        }
    }
    public void Apilar(int dato){
        if(!esLlena()){
            for(int i = 1; i <=6; i++);
            vector[cima]=dato;
        }else{
            System.out.println("La pila esta llena");
        }
    }
    public void desapilar(){
        if(!esVacia()){
            cima--;
        }else{
            System.out.println("Pila vacia");
        }
    }
    public void ObtenerCima(){
        if(!esVacia()){
            System.out.println("El elemeto que esta en la cima es: "+vector[cima]);
        }else{
            System.out.println("Pila vacia");
        }
    }
    public void  mostrar(){
        if(!esVacia()){
            for(int i=cima;i>=0;i--){
                System.out.println(vector[i]);
            }
        }else{
            System.out.println("Pila vacia");
        }
    }
}