import java.util.Scanner;
import java.util.LinkedList;
public class TestReproductor {
    public static void main (String[]args){
        
        int opcion;
       
        do{ 
                System.out.println("-----Reproductor-----");
            System.out.println(" Que tipo de pista desea buscar");
            System.out.println("1.Audio \n2.Video \n3. Salir "); 
            Scanner s = new Scanner(System.in);
            opcion = s.nextInt();
            switch(opcion){
                case 1 -> {
                    System.out.println("Pista de audio");
                    Audio1(opcion);
                }
                case 2 -> {
                    System.out.println("Pista de Video");
                    Video1(opcion);
                }
                case 3 -> {
                }
                default -> System.out.println("INCORRECTO");
            }
        }while(opcion !=3);
                
    }
    public static int Menu(int opcion){
        Scanner s = new Scanner(System.in);
        System.out.println("""
                           1.---Insertar pista al inicio--- 
                           2.---Insertar pista al final ---
                           3.---Eliminar pista del inicio ---
                           4.---Eliminar pista del final ---
                           5.---Buscar por nombre ---
                           6.---Reproducir por nombre ---
                           7.---Reproducir en orden--- 
                           8.---Mostrar Pistas--- 
                           9.--Salir---""");
        opcion = s.nextInt();
        return opcion;
    }
    public static void Audio1(int opcion){
        Scanner s = new Scanner(System.in);
        String a,b,bus;
        LinkedList<Audio>list = new LinkedList();
        do{
            opcion=Menu(opcion);
            switch(opcion){
                case 1 -> { 
                    System.out.println("Nombre del audio");
                    a = s.next();
                    System.out.println(" Nombredel Autor");
                    b = s.next();
                    System.out.println("Cual es la duracion");
                    int dur = s.nextInt();
                    Audio e = new Audio(b,a,dur);
                    list.addFirst(e);
                }
                    case 2 -> {
                        System.out.println("Nombre del audio");
                        a= s.next();
                        System.out.println("Nombredel Autor");
                        b=s.next();
                        System.out.println("Cual es la duracion");
                    int dur = s.nextInt();
                    Audio e = new Audio(b,a,dur);
                    list.addLast(e);
                }
                case 3 -> {
                    if(!list.isEmpty()){
                        System.out.println("Se ha quitado: "+list.getFirst());
                        list.removeFirst();
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                }
                case 4 -> {
                    if(!list.isEmpty()){
                        System.out.println("Se ha removido: "+list.getLast());
                        list.removeLast();
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                }
                case 5 -> {
                    boolean enc=false;
                    if(!list.isEmpty()){
                        System.out.println("Escribe el nombre del audio");
                        bus =s.next();
                        for(int i=0;i<list.size();i++){
                            if(!list.get(i).Titulo.equals(bus)){
                                enc=false;
                            }
                            else{
                                enc=true;
                            }
                        }
                        if(enc=true){
                            System.out.println("Existe el audio");
                        }else{
                            System.out.println("No existe....");
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                }
                case 6 -> {
                    boolean enc = false;
                    if(!list.isEmpty()){
                        System.out.println("Escribe el nombre del audio");
                        bus =s.next();
                        for(int i=0;i<list.size();i++){
                            if(!list.get(i).Titulo.equals(bus)){
                                enc=false;
                            }
                            else{
                                System.out.println("Audio encontrado: ");
                                System.out.println(list.get(i));
                            }
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                }
                case 7 -> {
                    if(!list.isEmpty()){
                        for(int i=0;i<list.size();i++){
                            System.out.println("Reproduciendo: ");
                            System.out.println(list.get(i).Titulo);
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                }
                case 8 -> {
                    if(!list.isEmpty()){
                        System.out.println("Los audios fueron almacenados: ");
                        for(int i=0;i<list.size();i++){
                            System.out.println("\n"+(i+1)+".- "+list.get(i).toString()+"\n");
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                }
                case 9 -> System.out.println("Saliendo...");
                default -> System.out.println("Incorrecto");
            }
        }while(opcion!=9);
    }
    public static void Video1(int opc){
        Scanner s = new Scanner(System.in);
        String a,b,bus;
        boolean enc=false;
        LinkedList<Video>lista = new LinkedList<>();
        do{
            opc=Menu(opc);
            switch(opc){
                
                case 1: System.out.println("Nombre del video");
                    a= s.next(); 
                    System.out.println("Cual es el Formato");
                    b=s.next();
                    System.out.println("Cuanto dura");
                    int dur=s.nextInt();
                    Video e = new Video(b,a,dur);
                    lista.addFirst(e);
                    break;
                case 2:System.out.println("Nombre del video");
                    a= s.next(); 
                    System.out.println("Cual es el Formato");
                    b=s.next();
                    System.out.println("Cuanto dura");
                    dur=s.nextInt();
                    e = new Video(b,a,dur);
                    lista.addLast(e);
                    break;
                case 3:
                    if(!lista.isEmpty()){
                        System.out.println("Se ha quitado: "+lista.getFirst());
                        lista.removeFirst();
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                    break;
                case 4:
                    if(!lista.isEmpty()){
                        System.out.println("Se ha quitado: "+lista.getLast());
                        lista.removeLast();
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                    break;
                case 5:
                    if(!lista.isEmpty()){
                        System.out.println("Escribe el nombre del video a buscar");
                        bus =s.next();
                        for(int i=0;i<lista.size();i++){
                            if(!lista.get(i).Titulo.equals(bus)){
                                enc=false;
                            }
                            else{
                                enc=true;
                            }
                        }
                        if(enc=true){
                            System.out.println("Existe el video");
                            }
                        else{
                            System.out.println("No existe");
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                    break;
                case 6:
                    enc=false;
                    if(!lista.isEmpty()){
                        System.out.println("Escribe el nombre del video a buscar");
                        bus =s.next();
                        for(int i=0;i<lista.size();i++){
                            if(!lista.get(i).Titulo.equals(bus)){
                                enc=false;
                            }
                            else{
                                System.out.println("Video encontrado: ");
                                System.out.println(lista.get(i));
                            }
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                    break;
                case 7:
                    if(!lista.isEmpty()){
                        for(int i=0;i<lista.size();i++){
                            System.out.println("Reproduciendo: ");
                            System.out.println(lista.get(i).Titulo);
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                    break;
                case 8:
                    if(!lista.isEmpty()){
                        System.out.println("Videos Almacenadas: ");
                        for(int i=0;i<lista.size();i++){
                            System.out.println("\n"+(i+1)+".- "+lista.get(i).toString()+"\n");
                        }
                    }
                    else{
                        System.out.println("Lista Vacia...");
                    }
                    break;
                case 9:System.out.println("Regresando...");
                    break;
                default:System.out.println("Opcion no valida");
                    break;
            }
        }while(opc!=9);
        
    }
}
