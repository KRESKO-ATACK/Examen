import java.util.Scanner;

public class TestZapateria {
    
     public static void main(String[]args){
        int opcion;
        Scanner s = new Scanner(System.in);
        
        Zapateria z = new Zapateria();
       
        
        System.out.println("\n ------------BIENVENIDO-----------");
        do{ 
            System.out.println("-----QUE MOVIMIENTO PIENSA HACER-----");
            System.out.println("1.Comprar \n2. Pagar \n3. Imprimir recibo \n4. Salir");
            opcion = s.nextInt();
            switch(opcion){
                case 1->{
                    System.out.println("Cuantos zapatos quieres comprar");
                    z.Comprar();
                    z.Comprar(z.getZapatos(),z.getCliente(),z.getCantidadDeZapatos());
                }
                case 2->{
                    System.out.println("Su total a pagar es de:");
                    z.Pagar();
                    z.CalculaDescuento();
                    z.CalcularDescuento(z.getCliente(),z.getZapatos(),z.getCantidadDeZapatos());
                }
                case 3->{
                    System.out.println("El ticket de su compra es:");
                    z.ImprimirTicket();
                }
                case 4->{
                    System.out.println("Gracias por visitarnos");
                }
                default->
                    System.out.println("OPCION ERRONEA");
                        }
            }while(opcion!=3);
        
        }
}