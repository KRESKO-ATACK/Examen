
public class Audio extends Reproductor {
    private String autor;

    public Audio(){
        
    }

    public Audio(String autor) {
        this.autor = autor;
    }
    
    public Audio(String autor, String Titulo, int duracion) {
        super(Titulo, duracion);
        this.autor = autor;
    }
    

    public String getAutor() {
        return autor;
    }

    
    @Override
    public String toString(){
        return "Audio: \n Titulo del audio:"+Titulo+"\n Cuanto dura:"+duracion+"\n"
                + "Nombre del aut@r: "+autor;
    }

    
    
}
