import java.util.Scanner;

public class TestSuperheores{
    public static void main (String [] args) {
        //Constructores
        Scanner s = new Scanner(System.in);
        String cad;
        //Creacion de objetos
        
       Superheroe miSuperheroe1 = new Superheroe();

       Superheroe miSuperheroe2 = new Superheroe();
              
       Superheroe miSuperheroe3 = new Superheroe();
       
       //Caracterisitcas de superheroes
       System.out.println("Nombre.....");
       cad = s.next();
       miSuperheroe1.setNombre(cad);
       
       System.out.println("Nombre.....");
       cad = s.next();
       miSuperheroe2.setNombre(cad);
       
       System.out.println("Nombre.....");
       cad = s.next();
       miSuperheroe3.setNombre(cad);
       
       System.out.println("Poder......");
       cad = s.next();
       miSuperheroe1.setPoder(cad);
       
       System.out.println("Poder......");
       cad = s.next();
       miSuperheroe2.setPoder(cad);
       
       System.out.println("Poder......");
       cad = s.next();
       miSuperheroe3.setPoder(cad);
       //Nombre
       System.out.println("El Super Heroe se llama....."+miSuperheroe1.getNombre());
       System.out.println("El Super Heroe se llama....."+miSuperheroe2.getNombre());
       System.out.println("El Super Heroe se llama....."+miSuperheroe3.getNombre());
       System.out.println("El Super Heroe se llama....."+miSuperheroe1.getNombre());
       //Poder
       System.out.println("El Super Heroe tiene el....."+miSuperheroe1.getPoder());
       System.out.println("El Super Heroe se llama....."+miSuperheroe2.getPoder()); 
       System.out.println("El Super Heroe se llama....."+miSuperheroe3.getPoder()); 
       //Mundo
       System.out.println("El Super Heroe se llama....."+miSuperheroe1.getMundo());
       System.out.println("El Super Heroe se llama....."+miSuperheroe2.getMundo());
       System.out.println("El Super Heroe se llama....."+miSuperheroe3.getMundo());
       
      

       
        //Acciones
       miSuperheroe1.revisarlaCiudad();
       miSuperheroe1.Volar();
       miSuperheroe1.casa();
       miSuperheroe2.revisarlaCiudad();
       miSuperheroe2.Volar();
       miSuperheroe2.casa();   
       miSuperheroe3.revisarlaCiudad();
       miSuperheroe3.Volar();
       miSuperheroe3.casa();
    }
}