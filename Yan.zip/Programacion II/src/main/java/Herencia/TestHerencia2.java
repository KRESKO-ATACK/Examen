package Herencia;

import java.util.Scanner;

public class TestHerencia2 {
  
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        int opcion;
        int opcion2;
        String aux;
        String buscador;
        double a;
        int b;
        int i=0;
        int j=0;
        Libro[] Lib= new Libro [10];
        CD[] C = new CD[10];
        int z;
        int y;
        boolean iguales=false;
               
        do{
            System.out.println("1.Alta de publicaciones\n2.Visualisar Almacen\n3.Buscar\n4. salir");
            opcion= s.nextInt();
            switch(opcion){
                case 1:
                    
                    do{
                    System.out.println("1.Alta de libro \n 2.alta de CD \n 3.Volver");
                    opcion2 = s.nextInt();
                        switch(opcion2){
                            case 1:
                                 System.out.println("Titulo del libro");
                                 aux = s.next();
                                 System.out.println("Precio: ");
                                 a = s.nextDouble();
                                 System.out.println("Numero de paginas");
                                 b = s.nextInt();
                                 Lib [i] = new Libro(b,aux,a);
                                 System.out.println(Lib[i]);
                                 i++;
                                 break;      
                            case 2:
                                System.out.println("Titulo del CD");
                                aux = s.next();
                                System.out.println("Precio: ");
                                a = s.nextDouble();
                                System.out.println("tiempo de reproduccion");
                                b = s.nextInt();
                                C [j] = new CD (b, aux, a);
                                System.out.println(C[j]);
                                j++;
                                break;
                                
                            case 3:
                                break;
                                
                            default: System.out.println("Ingrese una opcion valida");
                        }
                    }while(opcion2 != 3);
                    break;
                case 2: 
                    do{
                         System.out.println("1.Visualizar libros\n2.Visualizar CDs\n3.Visualizar todo\n4.Volver");
                         opcion2 = s.nextInt();
                         switch(opcion2){
                             case 1:
                                 if(i<=0){
                                    System.out.println("No hay libros en el almacen");
                                 }else{
                        
                                    for(z=0; z<i; z++){
                                    System.out.println(Lib[z]);
                                    }
                                 }
                                     
                                 break;
                             case 2:
                                 if(j<=0){
                                    System.out.println("No hay CDs en el almacen");
                                }else{
                                    for(y=0; y<j; y++){
                                    System.out.println(C[y]);
                                    }
                                }
                                 break;
                             case 3:
                                 if(i<=0 && j<=0){
                                    System.out.println("El almacen esta vacio");
                                 }else if(i<=0 && j>0){
                                    System.out.println("No hay libros en el almacen");  
                                    for(y=0; y<j; y++){
                                    System.out.println(C[y]);
                                    }
                                 }else if(i>0 && j<=0){
                                     System.out.println("No hay Cds en el almacen");  
                                    for(z=0; z<i; z++){
                                    System.out.println(Lib[z]);
                                    }
                                 }else if(i>0 && j>0 ){
                                    for(z=0; z<i; z++){
                                    System.out.println(Lib[z]);
                                    }
                                    for(y=0; y<j; y++){
                                    System.out.println(C[y]);
                                    }                               
                                 }          
                                 break;
                             case 4: 
                                 break;
                             default: System.out.println("ingrese una opcion valida");
                         
                         }
                    }while(opcion2 != 4);
                    break;
                case 3:     
                    do{
                        System.out.println("1.Buscar libro\n2.Buscar CD\n3.Volver");
                        opcion2 = s.nextInt();
                        switch(opcion2){
                            case 1: 
                                System.out.println("Introduzca el nombre del Libro a buscar:");
                                buscador = s.next();
                                iguales=false;
                                for(z=0;z<i;z++){
                                    boolean esigual = buscador.equalsIgnoreCase(Lib[z].getTitulo());
                                    if(esigual){
                                        System.out.println(Lib[z]);
                                        iguales=esigual;
                                        break;
                                    }                        
                                }                                                        
                            if(iguales==false){
                                System.out.println("No se encontró el libro");
                            }    
                            break;
                            case 2: 
                                System.out.println("Introduzca el nombre del CD a buscar:");
                                buscador=s.next();
                                iguales=false;
                                for(z=0;z<i;z++){
                                   boolean esigual = buscador.equalsIgnoreCase(C[z].getTitulo());
                                    if(esigual){
                                        System.out.println(C[z]);
                                        iguales=esigual;
                                        break;
                                    }                        
                                }                                                        
                            if(iguales==false){
                                System.out.println("No se encontró el CD");
                            }    
                            break;
                            
                            case 3:
                            break;
                            
                            default: System.out.println("Ingrese una opcion valida");
                        }
                    
                    }while(opcion2 != 3);               
                    break;                    
                case 4: 
                    System.out.println("adios");
                    break;              
                default: System.out.println("opcion incorrecta");       
            }
        }while(opcion != 4 );            
    }   
}

