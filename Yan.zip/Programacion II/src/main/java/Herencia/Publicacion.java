package Herencia;

public class Publicacion {
    protected String titulo;
    protected double precio;
    
    public Publicacion(){}

    public Publicacion(String titulo, double precio) {
        this.titulo = titulo;
        this.precio = precio;
    }

    public String getTitulo() {
        return titulo;
    }

    public double getPrecio() {
        return precio;
    }
    
    @Override
    public String toString(){
        return "--PUBLICACION--\nTitulo: "+titulo+"\nPrecio: "+precio;
    }
    
}
